package puke;

public class Card {
	
	int[] card6 = new int[6];//���ڴ洢��ҵ�3����
	String[] card_6 = new String[6];
	int[] a = new int[6];//����
	int[] b = new int[6];//��ɫ
	//int flag = 0;//���ڴ洢��ͬ�����Ƶĵȼ��������ж�
	void random(){//������������
		for( int i = 0; i < card6.length; i++ ){
			card6[i] = (int)(Math.random()*51+1);
			a[i]=card6[i]/4;//����
			b[i]=card6[i]%4;//��ɫ
			if(i==1 && card6[1]==card6[0]||
				i==2 && (card6[2]==card6[0]|| card6[2]==card6[1])||
				i==3 && (card6[3]==card6[0]|| card6[3]==card6[1]||card6[3]==card6[2])||
				i==4 && (card6[4]==card6[0]|| card6[4]==card6[1]||card6[4]==card6[2]||card6[4]==card6[3])||
				i==5 && (card6[5]==card6[0]|| card6[5]==card6[1]||card6[5]==card6[2]||card6[5]==card6[3]||card6[5]==card6[4])
			)
			{
				i--;
			}
		}
		for( int i = 0; i <card6.length; i++ ){
			switch( a[i] ){
			case 0:card_6[i] = "2";break;
			case 1:card_6[i] = "3";break;
			case 2:card_6[i] = "4";break;
			case 3:card_6[i] = "5";break;
			case 4:card_6[i] = "6";break;
			case 5:card_6[i] = "7";break;
			case 6:card_6[i] = "8";break;
			case 7:card_6[i] = "9";break;
			case 8:card_6[i] = "10";break;
			case 9:card_6[i] = "J";break;
			case 10:card_6[i] = "Q";break;
			case 11:card_6[i] = "K";break;
			case 12:card_6[i] = "A";break;
			}
			switch(b[i]) {
			case 0:card_6[i]="����"+card_6[i];break;
			case 1:card_6[i]="����"+card_6[i];break;
			case 2:card_6[i]="÷��"+card_6[i];break;
			case 3:card_6[i]="����"+card_6[i];break;
			}
		}
		//System.out.print( p.name + "����Ϊ:");
		for( int k = 0; k < card6.length; k++ ){
			System.out.print( "   " + card_6[k] );
		}
		System.out.println("");
	}
}
