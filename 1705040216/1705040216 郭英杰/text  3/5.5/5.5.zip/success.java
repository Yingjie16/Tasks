package puke;



public class success {
	 Card ca = new Card();

 public void  success( ){
		 
		 int flag1;
		int flag2;
			if( ca.b[0]==ca.b[1] && ca.b[1]==ca.b[2] 
					&& ca.b[0]==ca.b[2]){
				flag1 = 5;
			}else if( ca.a[0]==(ca.a[1]+1) && ca.a[0]==(ca.a[2]+2)||
					ca.a[0]==(ca.a[1]+2) && ca.a[0]==(ca.a[2]+1)||
					ca.a[1]==(ca.a[0]+2) && ca.a[1]==(ca.a[2]+1)||
					ca.a[1]==(ca.a[0]+1) && ca.a[1]==(ca.a[2]+2)||
					ca.a[2]==(ca.a[0]+2) && ca.a[2]==(ca.a[1]+1)||
					ca.a[2]==(ca.a[0]+1) && ca.a[2]==(ca.a[1]+2)){
				flag1 = 4;
			}else if( ca.a[0]==ca.a[1] && ca.a[1]==ca.a[2] 
					&& ca.a[0]==ca.a[2]){
				flag1 = 3;
			}else if( ca.a[0]==ca.a[1] || ca.a[0]==ca.a[2]
					|| ca.a[1]==ca.a[2] ){
				flag1 = 2;
			}else{
				flag1 = 1;
			}
			
			if( ca.b[3]==ca.b[4] && ca.b[5]==ca.b[4] 
					&& ca.b[3]==ca.b[5]){
				flag2 = 5;
			}else if( ca.a[3]==(ca.a[4]+1) && ca.a[3]==(ca.a[5]+2)||
					ca.a[3]==(ca.a[4]+2) && ca.a[3]==(ca.a[5]+1)||
					ca.a[4]==(ca.a[3]+2) && ca.a[4]==(ca.a[5]+1)||
					ca.a[4]==(ca.a[3]+1) && ca.a[4]==(ca.a[5]+2)||
					ca.a[5]==(ca.a[3]+2) && ca.a[5]==(ca.a[4]+1)||
					ca.a[5]==(ca.a[3]+1) && ca.a[5]==(ca.a[4]+2)){
				flag2 = 4;
			}else if( ca.a[3]==ca.a[4] && ca.a[4]==ca.a[5] 
					&& ca.a[3]==ca.a[5]){
				flag2 = 3;
			}else if( ca.a[3]==ca.a[4] || ca.a[3]==ca.a[5]
					|| ca.a[4]==ca.a[5] ){
				flag2 = 2;
			}else{
				flag2 = 1;
			}
		 
		zhu.win.textField.setText(ca.card_6[0]);
		zhu.win.textField_1.setText(ca.card_6[1]);
		zhu.win.textField_2.setText(ca.card_6[2]);
		zhu.win.textField_3.setText(ca.card_6[3]);
		zhu.win.textField_4.setText(ca.card_6[4]);
		zhu.win.textField_5.setText(ca.card_6[5]);
		if( flag1 >flag2 ){
			//p1.win = 1;
			zhu.win.textField_5.setText("player1 win");
		}else if( flag1 == flag2 ){
			if( ca.a[0]+ca.a[1]+ca.a[2] >ca.a[3]+ca.a[4]+ca.a[5] ){
				//p1.win = 1;
				zhu.win.textField_5.setText("player1 win");
				}else if(ca.a[0]+ca.a[1]+ca.a[2] <ca.a[3]+ca.a[4]+ca.a[5] ){
					//p2.win = 1;
					zhu.win.textField_5.setText("player2 win");
				}
				else {
					//System.out.println( "ƽ��" );	
					zhu.win.textField_5.setText("ƽ��");
				}
			}else{
				//p2.win = 1;
				zhu.win.textField_5.setText("player2 win");

		}
		//if( p1.win == 1 ){
		//	System.out.println( p1.name + "Ӯ" );
		//}else if(p1.win == 0){
		//	System.out.println( p2.name + "Ӯ" );
		}




	}

