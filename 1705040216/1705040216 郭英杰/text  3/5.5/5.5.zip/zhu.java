package puke;

public class zhu {
static ___gui win=null;
static Card card1=null;
static success su=null;
public static void main(String[] args) {
	// TODO �Զ����ɵķ������    
	card1=new Card();

	//Success.success();
	win=new ___gui();
	card1.random();
    su=new success();


}
}
