package tss;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class tss extends JFrame implements ActionListener {
	// �������
	JLabel jLStudentInfoTable = null;//ѧ����Ϣ��
	JLabel jLSelectQueryField = null;//ѡ���ѯ�ֶ�
	JLabel jLEqual = null;//=
	JLabel jLname = null;//����
	JLabel jLsalary = null;//нˮ
	JLabel jLpeople = null;//��������
	JLabel jLyear = null;//����
	JLabel jLcsalary = null;//��нˮ
	JLabel jLtime = null;//��ְʱ��

	JTextField jTFQueryField = null;//��ѯ�ֶ�
	JTextField jTFname = null;//����
	JTextField jTFsalary = null;//нˮ
	JTextField jTFpeople = null;//��������
	JTextField jTFyear = null;//����
	JTextField jTFcsalary = null;//��нˮ
	JTextField jTFtime = null;//��ְʱ��
	
	JButton jBQuery = null;//��ѯ
	JButton jBQueryAll = null;//��ѯ���м�¼
	JButton jBInsert = null;//����
	JButton jBUpdate = null;//����
	JButton jBDeleteCurrentRecord = null;//ɾ����ǰ��¼
	JButton jBDeleteAllRecords = null;//ɾ�����м�¼
	
	//JComboBox jCBSelectQueryField = null;
	JComboBox<String> jCBSelectQueryField = null;//��ѯ�ֶ�
	JPanel jP1, jP2,jP3,jP4,jP5,jP6 = null;
	JPanel jPTop, jPBottom = null;
	DefaultTableModel studentTableModel = null;
	JTable studentJTable = null;
	JScrollPane studentJScrollPane = null;
	Vector studentVector = null;
	Vector titleVector = null;
	
	private static DbProcess dbProcess;
	String SelectQueryFieldStr = "����";
	
	// ���캯��
	public tss() {
		// �������	
		jLStudentInfoTable = new JLabel("\u6559\u5E08\u4FE1\u606F\u8868");
		jLname = new JLabel("����");
		jLsalary = new JLabel("нˮ");
		jLpeople = new JLabel("��������");
		jLyear = new JLabel("����");
		jLcsalary = new JLabel("��нˮ");
		jLtime = new JLabel("��ְʱ��");
		jTFname = new JTextField(10);//����
		jTFsalary = new JTextField(10);//нˮ
		jTFpeople = new JTextField(10);//��������
		jTFyear = new JTextField(10);//����
		jTFcsalary = new JTextField(10);//��нˮ
		jTFtime = new JTextField(10);
		jBQueryAll = new JButton("\u67E5\u8BE2\u5149\u76D8");
		jBUpdate = new JButton("����");
		jBQueryAll.addActionListener(this);
		jBUpdate.addActionListener(this);
	
		studentVector = new Vector();
		titleVector = new Vector();
		
		// �����ͷ
		titleVector.add("����");
		titleVector.add("нˮ");
		titleVector.add("��������");
		titleVector.add("����");
		titleVector.add("��нˮ");
		titleVector.add("��ְʱ��");
		//studentTableModel = new DefaultTableModel(tableTitle, 15);
		studentJTable = new JTable(studentVector, titleVector);
		studentJTable.setPreferredScrollableViewportSize(new Dimension(450,160));
		studentJScrollPane = new JScrollPane(studentJTable);
		//�ֱ�����ˮƽ�ʹ�ֱ�������Զ�����
		studentJScrollPane.setHorizontalScrollBarPolicy(                
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		studentJScrollPane.setVerticalScrollBarPolicy(                
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		//Ϊ�������Ӽ����� 
		studentJTable.addMouseListener(new MouseAdapter()
		{ 
			public void mouseClicked(MouseEvent e) 
			{ 
				int row = ((JTable) e.getSource()).rowAtPoint(e.getPoint()); // �����λ��
				System.out.println("mouseClicked(). row = " + row);
				Vector v = new Vector();
				v = (Vector) studentVector.get(row);

				jTFname.setText((String) v.get(0));// ����
				jTFsalary.setText((String) v.get(1));// нˮ
				jTFpeople.setText((String) v.get(2));// ��������
				jTFyear.setText((String) v.get(3));// ����
				jTFcsalary.setText((String) v.get(4));// ��нˮ
				jTFtime.setText((String) v.get(5));// ��ְʱ��
			}
		});


		jP1 = new JPanel();
		jP2 = new JPanel();
		jP3 = new JPanel();
		jP4 = new JPanel();
		jP5 = new JPanel();
		jP6 = new JPanel();
		jPTop = new JPanel();
		jPBottom = new JPanel();
		
		jP1.add(jLStudentInfoTable,BorderLayout.SOUTH);
		jP2.add(studentJScrollPane);
		jP3.add(jBQueryAll);
		jP3.setLayout(new FlowLayout(FlowLayout.LEFT));
		jP3.setPreferredSize(new Dimension(20,20));
		
		jP4.add(jLname);
		jP4.add(jTFname);
		jP4.add(jLsalary);
		jP4.add(jTFsalary);
		jP4.add(jLpeople);
		jP4.add(jTFpeople);
		jP4.setLayout(new FlowLayout(FlowLayout.LEFT));
		jP4.setPreferredSize(new Dimension(20,20));
	
		jP5.add(jLyear);
		jP5.add(jTFyear);
		jP5.add(jLcsalary);
		jP5.add(jTFcsalary);
		jP5.add(jLtime);
		jP5.add(jTFtime);
		jP5.setLayout(new FlowLayout(FlowLayout.LEFT));
		jP5.setPreferredSize(new Dimension(20,20));
		jP6.add(jBUpdate);
		jP6.setLayout(new FlowLayout(FlowLayout.LEFT));
		jP6.setPreferredSize(new Dimension(20,20));
		
		jPTop.add(jP1);
		jPTop.add(jP2);
		
		jPBottom.setLayout(new GridLayout(4, 1));
		jPBottom.add(jP3);
		jPBottom.add(jP4);
		jPBottom.add(jP5);
		jPBottom.add(jP6);
		
		getContentPane().add("North", jPTop);
		getContentPane().add("South", jPBottom);
	
		getContentPane().setLayout(new GridLayout(2, 1));
		this.setTitle("\u6559\u5E08\u5DE5\u8D44\u7CFB\u7EDF");
		this.setSize(500, 500);
		this.setLocation(150, 150);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setResizable(false);
		
		dbProcess = new DbProcess();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
if(e.getActionCommand().equals("��ѯ����")) {
			System.out.println("actionPerformed(). ��ѯ����");
			queryAllProcess();

		}else if(e.getActionCommand().equals("����")
				&& !jTFname.getText().isEmpty()
				&& !jTFsalary.getText().isEmpty()
				&& !jTFpeople.getText().isEmpty()
				&& !jTFyear.getText().isEmpty()
				&& !jTFcsalary.getText().isEmpty()
				&& !jTFtime.getText().isEmpty()){
			System.out.println("actionPerformed(). ����");
			updateProcess();
		}
	}
	
	public static void main(String[] args) {
        // TODO Auto-generated method stub
		tss getcon = new  tss();
    }
	

	
	public void queryAllProcess()
	{
		try{
			// ������ѯ����
			String sql = "select * from teacher;";
			System.out.println("queryAllProcess(). sql = " + sql);
	
			dbProcess.connect();
			ResultSet rs = dbProcess.executeQuery(sql);

			// ����ѯ��õļ�¼���ݣ�ת�����ʺ�����JTable��������ʽ
			studentVector.clear();
			while(rs.next()){
				Vector v = new Vector();
				v.add(rs.getString("name"));
				v.add(rs.getString("salary"));
				v.add(rs.getString("people"));
				v.add(rs.getString("year"));
				v.add(rs.getString("csalary"));
				v.add(rs.getString("time"));
				studentVector.add(v);
			}
			
			studentJTable.updateUI();

			dbProcess.disconnect();
		}catch(SQLException sqle){
			System.out.println("sqle = " + sqle);
			JOptionPane.showMessageDialog(null,
				"���ݲ�������","����",JOptionPane.ERROR_MESSAGE);
		}
	}
	


	public void updateProcess()
	{
		
		double a = Integer.parseInt(jTFsalary.getText());
		double b = Integer.parseInt(jTFyear.getText());
		double c = Integer.parseInt(jTFpeople.getText());
		double d = a+50*b+c*100;
		
		String name = jTFname.getText().trim();
		String csalary = String.valueOf(d);

		

		// ������������
		if(d<=26000) {
		String sql = "update teacher set csalary = '";
		sql = sql + csalary +"' WHERE name = '" + name + "';";
		System.out.println("updateProcess(). sql = " + sql);
		try{
			if (dbProcess.executeUpdate(sql) < 1) {
				System.out.println("updateProcess(). update database failed.");
			}
		}catch(Exception e){
			System.out.println("e = " + e);
			JOptionPane.showMessageDialog(null,
				"���ݲ�������","����",JOptionPane.ERROR_MESSAGE);
		}
		queryAllProcess();
		}
		else {
			String sql = "update teacher set csalary = '26000' where name='"+ name +"';";
			System.out.println("updateProcess(). sql = " + sql);
			try{
				if (dbProcess.executeUpdate(sql) < 1) {
					System.out.println("updateProcess(). update database failed.");
				}
			}catch(Exception e){
				System.out.println("e = " + e);
				JOptionPane.showMessageDialog(null,
					"���ݲ�������","����",JOptionPane.ERROR_MESSAGE);
			}
			queryAllProcess();
			}
		}	





	public String jCBSelectQueryFieldTransfer(String InputStr)
	{
		String outputStr = "";
		System.out.println("jCBSelectQueryFieldTransfer(). InputStr = " + InputStr);
		
		if(InputStr.equals("����")){
			outputStr = "name";
		}else if(InputStr.equals("нˮ")){
			outputStr = "salary";
		}else if(InputStr.equals("��������")){
			outputStr = "people";
		}else if(InputStr.equals("����")){
			outputStr = "year";
		}else if(InputStr.equals("��нˮ")){
			outputStr = "csalary";
		}else if(InputStr.equals("��ְʱ��")){
			outputStr = "time";
		}
		System.out.println("jCBSelectQueryFieldTransfer(). outputStr = " + outputStr);
		return outputStr;
	}
}
